1. install requirements using pip3 : -r requirements.txt
2. run ap.py through python3 app.py