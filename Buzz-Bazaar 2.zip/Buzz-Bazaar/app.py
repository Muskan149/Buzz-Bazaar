from flask import Flask, render_template, request
from flask_sqlalchemy import SQLAlchemy

from sqlalchemy.sql import func

from time import sleep

from datetime import datetime

from sheets import returnSheets


app = Flask(__name__, template_folder='templates')

TEMPERATURE = 0.5

@app.route("/", methods=["POST", "GET"])
def index():
    affirmations = []
    grievance = ""
    flashMessage = False
    requestPosted = False
    if request.method == 'POST':
        action = request.form['action']
        print(action)
        if action.lower() == "buy":
            return render_template("index3.html", data = returnSheets())
        if "rent" in action.lower(): # i wanna rent a dress weee
            return render_template("index4.html", data = returnSheets("1rYYJulVbB2jdHdqfW1R2U4tWbRNC51kqvDKMqJYJ4eg", "A2:N"))

    return render_template("index.html", grievance=grievance, affirmations=affirmations, flashMessage=flashMessage, requestPosted=requestPosted)


if __name__ == "__main__":
    print("starting app...")
    app.run(debug=True, port=3413)
